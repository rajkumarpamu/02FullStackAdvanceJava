

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;



public class AuthorizationFilter implements Filter {

    
    public AuthorizationFilter() {
     System.out.println("AuthorizationFilter filter object created");
    }


	public void destroy() {
		System.out.println("Destroy method Invoked");
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		PrintWriter pw = response.getWriter();
		String name = request.getParameter("name");
		String password = request.getParameter("password");
		
		if(name.equals("admin") & password.equals("admin")) {
	
			long before = System.currentTimeMillis();
			chain.doFilter(request, response);
			long after = System.currentTimeMillis();
			pw.println("Total Response time :"+(after-before));
		}
		else {
			
			pw.println("Invalid username/password");
			
			RequestDispatcher rd = request.getRequestDispatcher("index.html");
			rd.include(request, response);
		}
		
	}

	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
